package view;

import model.WordGuess;
import javax.swing.JFrame;

import controller.WordGuessListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.Container;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.util.ArrayList;
import java.awt.BorderLayout;

public class WordGuessPanel {

	public final static int MAX_HEALTH = 5;
	private int health = MAX_HEALTH;
	private Status gameStatus = Status.UNDEFINED;

	private JFrame window = new JFrame(" ");
	private JPanel centerPanel = new JPanel();
	private JLabel wordLabel= new JLabel(" ");
	private JLabel guessLabel= new JLabel();
	private WordGuess guess;
	private WordGuessCanvas canvas;
	private ArrayList<JButton> guessButtonList = new ArrayList<>();
	private JButton newButton = new JButton("New");
	private WordGuessListener listener = new WordGuessListener(this);

	public WordGuessPanel(JFrame window){
		this.window = window;
		window.setPreferredSize(new Dimension(600,600));
	}

	public void init(){
		
		window.setTitle("Project1: Word Guess Game");

		Container cp = window.getContentPane();
		guess = new WordGuess();
		JPanel northPanel = new JPanel();
		wordLabel.setForeground(Color.red);
		wordLabel.setBorder(BorderFactory.createLineBorder(new Color(179,205,224)));
		guessLabel.setBorder(BorderFactory.createLineBorder(new Color(179,205,224)));
		northPanel.setLayout(new GridLayout(2,1));
		northPanel.add(wordLabel);
		northPanel.add(guessLabel);
		cp.add(BorderLayout.NORTH, northPanel);

		//Add center canvas Later
		canvas = new WordGuessCanvas(this);
		centerPanel.add(canvas);
		cp.add(BorderLayout.CENTER, centerPanel);

		createButtonList();
		JPanel southPanel = new JPanel();
		southPanel.setLayout(new GridLayout(4,7));
		for(int i = 0; i < guessButtonList.size(); i++){
			southPanel.add(guessButtonList.get(i));
		}
		southPanel.add(newButton);
		cp.add(BorderLayout.SOUTH, southPanel);


		//ActionListeners
		newButton.addActionListener(listener);
		
		for(int i = 0; i < guessButtonList.size(); i++){
			guessButtonList.get(i).addActionListener(listener);
		}
		
	}

	private void createButtonList(){
		char value = 'a';

		for(int i = (int) value; i < (int)value + 26; i++ ){
			char buttonChar = (char) i;
			JButton button = new JButton(""+buttonChar);
			button.setEnabled(false);
			guessButtonList.add(button);
		}
	}

	public WordGuess getWordGuess(){
		return guess;
	}

	public void setWordGuess(WordGuess guess){
		this.guess = guess;
	}

	public JButton getNewButton(){
		return newButton;
	}

	public ArrayList<JButton> getGuessButtonList(){
		return guessButtonList;
	}
	
	public JLabel getWordLabel(){
		return wordLabel;
	}

	public JLabel getGuessLabel(){
		return guessLabel;
	}

	public JFrame getWindow() {
		return window;
	}

	public WordGuessCanvas getCanvas(){
		return canvas;
	}

	public void setCanvas(WordGuessCanvas canvas){
		this.canvas  = canvas;
	}


	public int getHealth() {
		return health;
	}

	public void setHealth(int health){
		this.health = health;
	}

	public void updateHealth(){
		health = MAX_HEALTH - guess.getWrongGuessCount();
	}

	public Status getStatus() {
		return gameStatus;
	}

	public void setStatus(Status gameStatus){
		this.gameStatus = gameStatus;
	}

	public void updateStatus() {
		updateHealth();

		if (health > 0) {
			if(guess.getRightGuessCount() == guess.getWord().length()){
				gameStatus = Status.WIN;
			}
			else{
				gameStatus = Status.READY;
			}
		}
		else{
			gameStatus = Status.LOST;
		}
	}

	public enum Status {
		UNDEFINED, READY, WIN, LOST;
	}

}