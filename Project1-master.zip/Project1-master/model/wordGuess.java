package model;

import java.util.ArrayList;
import java.util.Random;

public class WordGuess {
	
	private int rightGuessCount = 0;
	private int wrongGuessCount = 0;
	private String guess = "";
	private char guessChar;
	private String word = "";
	private ArrayList<String> wordPool = new ArrayList<>();

	public WordGuess() {
		buildPool();
		word = wordPool.get((new Random()).nextInt(33));
		initializeGuess();
	}

	public ArrayList<String> getWordPool(){
		return wordPool;
	}

	public String getWord() {
		return word;
	}

	public void setGuessChar(char guessChar) {
		this.guessChar = guessChar;
	}

	public void initializeGuess() {
		guess = "";
		for (int i = 0; i < word.length(); i++) {
			guess += ".";
		}
	}

	public void checkGuess() {
		boolean flag = false;
		for (int i = 0; i < word.length(); i++) {
			if (guessChar == word.charAt(i)) {
				updateGuess(i);
				rightGuessCount++;
				flag = true;
			}
		}
		if(!flag){
			wrongGuessCount++;
		}
	}

	public void updateGuess(int index) {
		char[] array = new char[guess.length()];
		for (int i = 0; i < guess.length(); i++) {
			if (i == index) {
				array[i] = guessChar;
			} else {
				array[i] = guess.charAt(i);
			}
		}
		String temp = "";
		for (int i = 0; i < guess.length(); i++) {
			temp += array[i];
		}
		guess = temp;
	}

	public String getGuess() {
		return guess;
	}

	public void setGuess(String guess) {
		this.guess = guess;
	}

	public int getRightGuessCount(){
		return rightGuessCount;
	}

	public int getWrongGuessCount(){
		return wrongGuessCount;
	}

	public void buildPool() {
		wordPool.add("communication");
		wordPool.add("science");
		wordPool.add("programming");
		wordPool.add("language");
		wordPool.add("difficulty");
		wordPool.add("artificial");
		wordPool.add("intelligence");
		wordPool.add("attempts");
		wordPool.add("screenshot");
		wordPool.add("baseball");
		wordPool.add("windows");
		wordPool.add("learning");
		wordPool.add("electronics");
		wordPool.add("beautiful");
		wordPool.add("internet");
		wordPool.add("database");
		wordPool.add("organization");
		wordPool.add("application");
		wordPool.add("network");
		wordPool.add("friendly");
		wordPool.add("validation");
		wordPool.add("attempts");
		wordPool.add("statistics");
		wordPool.add("physics");
		wordPool.add("chemistry");
		wordPool.add("engineering");
		wordPool.add("school");
		wordPool.add("industry");
		wordPool.add("revolution");
		wordPool.add("progress");
		wordPool.add("characters");
		wordPool.add("heavily");
		wordPool.add("graphics");
	}
}
