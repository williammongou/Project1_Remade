package view;

import javax.swing.JPanel;

import view.WordGuessPanel.Status;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Color;
import java.awt.Font;

public class WordGuessCanvas extends JPanel {
	private WordGuessPanel panel;

	public WordGuessCanvas(WordGuessPanel panel){
		this.panel = panel;
		setPreferredSize(new Dimension(500,500));
	}

	@Override
	public void paintComponent(Graphics g){
		super.paintComponent(g);

		Graphics2D g2 = (Graphics2D) g;

		if(panel.getStatus() == Status.UNDEFINED){
			g2.setColor(Color.blue);
			g2.setFont(new Font("Seriff Plain", Font.BOLD, 30));
			g2.drawString("Press <NEW> to start", 70, 150);
		}
		//Ready to play
		else if(panel.getStatus() == Status.READY){

			//Display guess and word
			g2.setColor(Color.red);
			g2.setFont(new Font("Seriff Plain", Font.PLAIN, 30));
			g2.drawString("Health Level", 70, 150);

			g2.setColor(Color.blue);
			g2.setFont(new Font("Seriff Plain", Font.PLAIN, 30));
			g2.drawString("Health Level", 70, 150);
			for(int i = 0; i < panel.getHealth(); i++){	
				g2.setColor(Color.blue);
				g2.fillRect(50*i + 70, 200, 30, 40);
			}
		}
		else if(panel.getStatus() == Status.LOST){
				g2.setColor(Color.red);
				g2.setFont(new Font("Seriff Plain", Font.BOLD, 30));
				g2.drawString("YOU LOST !!!", 150, 120);
				g2.setColor(Color.blue);
				g2.drawString("Press <NEW> to start", 70, 150);
		}
		else{
			g2.setColor(Color.red);
			g2.setFont(new Font("Courrier New", Font.BOLD, 30));
			g2.drawString("YOU WON !!!", 150, 120);
			g2.setColor(Color.blue);
			g2.drawString("Press <NEW> to start", 70, 150);
		}
	}
}
