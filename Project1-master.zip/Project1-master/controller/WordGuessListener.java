package controller;

import java.awt.event.ActionListener;

import javax.swing.JButton;

import model.WordGuess;
import view.WordGuessPanel;
import view.WordGuessPanel.Status;

import java.awt.event.ActionEvent;

public class WordGuessListener implements ActionListener{
	
	private WordGuessPanel panel;
	
	public WordGuessListener(WordGuessPanel panel){
		this.panel = panel;
	}

	@Override
	public void actionPerformed(ActionEvent e){
		JButton button =(JButton) e.getSource();
	
		//Display word and guess on panel
		String word;
		String guess;

		if(button == panel.getNewButton()){
			//Create a new word guess object evertime
			panel.setWordGuess(new WordGuess());
			panel.setHealth(WordGuessPanel.MAX_HEALTH);
			panel.setStatus(Status.READY);
			panel.getCanvas().repaint();
			//Enable all letters
			for(int i = 0; i < panel.getGuessButtonList().size(); i++){
				panel.getGuessButtonList().get(i).setEnabled(true);
			}

			word = panel.getWordGuess().getWord();
			guess = panel.getWordGuess().getGuess();
			panel.getWordLabel().setText(word);
			panel.getGuessLabel().setText(guess);

		}
		else{
			panel.getWordGuess().setGuessChar(button.getText().charAt(0));
			panel.getWordGuess().checkGuess();
			panel.updateStatus();
			guess = panel.getWordGuess().getGuess();
			panel.getGuessLabel().setText(guess);
			button.setEnabled(false);
			panel.getCanvas().repaint();
			if(panel.getStatus() != Status.READY){
				for(int i = 0; i < panel.getGuessButtonList().size(); i++){
					panel.getGuessButtonList().get(i).setEnabled(false);
				}
				
			}			
		}
	}
}
