package test;

import model.WordGuess;

public class WordGuessTest {
	
	public static void main(String [] args){
		String testGuess = "abcdefghij";
		WordGuess myGuess = new WordGuess();

		System.out.println(myGuess.getWord());

		for(int i = 0; i < myGuess.getWordPool().size(); i++){
			// myGuess.setGuessChar(testGuess.charAt(i));
			// myGuess.checkGuess();
			// System.out.println(myGuess.getGuess());
			// System.out.println(myGuess.getRightGuessCount());
			// System.out.println(myGuess.getWrongGuessCount());

			// System.out.println(myGuess.getHealth());
		}
		
	}
}
